prérequis

installer node js sur votre ordinateur: https://nodejs.org/en/

puis choisisez la version LTS

une fois installer feser win+r est taper cmd

feser cd la racine de votre fichier

est executer la commande npm i

une fois terminer feser node index.js

